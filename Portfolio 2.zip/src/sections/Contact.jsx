import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Mail, Phone, MapPin, Send } from 'lucide-react'

const Contact = () => {
  // Individual intersection observers for sequential loading
  const [titleRef, titleInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  
  const [detailsRef, detailsInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })
  
  const [formRef, formInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  return (
    <section id="contact" className="py-20 bg-base-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div>
          {/* Header */}
          <motion.div 
            ref={titleRef}
            initial={{ opacity: 0, y: 50 }}
            animate={titleInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-neutral mb-4">
              Get In <span className="text-primary">Touch</span>
            </h2>
            <p className="text-neutral/70 max-w-2xl mx-auto">
              Have a question or want to work together? Reach out via the form or any of the contact details below.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Contact Details */}
            <motion.div 
              ref={detailsRef}
              initial={{ opacity: 0, x: -50 }}
              animate={detailsInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
              className="bg-base-100 rounded-2xl p-8 shadow-xl border border-base-300"
            >
              <h3 className="text-xl font-semibold text-neutral mb-6">Contact Details</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3 text-neutral/80">
                  <Mail className="w-5 h-5 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm">Email</p>
                    <a href="mailto:you@example.com" className="link link-primary text-sm">you@example.com</a>
                  </div>
                </li>
                <li className="flex items-start gap-3 text-neutral/80">
                  <Phone className="w-5 h-5 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm">Phone</p>
                    <a href="tel:+10000000000" className="link link-primary text-sm">+1 (000) 000-0000</a>
                  </div>
                </li>
                <li className="flex items-start gap-3 text-neutral/80">
                  <MapPin className="w-5 h-5 text-primary mt-0.5" />
                  <div>
                    <p className="text-sm">Location</p>
                    <p className="text-sm">Your City, Your Country</p>
                  </div>
                </li>
              </ul>

              <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/20">
                <p className="text-sm text-neutral/80">Prefer email? Click below to open your mail client with a prefilled subject.</p>
                <a
                  href="mailto:you@example.com?subject=Hi%20there!"
                  className="mt-3 inline-flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-focus transition-colors text-sm"
                >
                  <Send className="w-4 h-4" />
                  Email Me
                </a>
              </div>
            </motion.div>

            {/* Contact Form (non-functional placeholder) */}
            <motion.form
              ref={formRef}
              initial={{ opacity: 0, x: 50 }}
              animate={formInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
              transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
              className="bg-base-100 rounded-2xl p-8 shadow-xl border border-base-300"
              onSubmit={(e) => e.preventDefault()}
            >
              <h3 className="text-xl font-semibold text-neutral mb-6">Send a Message</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="form-control">
                  <label className="label"><span className="label-text">Name</span></label>
                  <input type="text" placeholder="Your name" className="input input-bordered" required />
                </div>
                <div className="form-control">
                  <label className="label"><span className="label-text">Email</span></label>
                  <input type="email" placeholder="you@example.com" className="input input-bordered" required />
                </div>
              </div>
              <div className="form-control mt-4">
                <label className="label"><span className="label-text">Subject</span></label>
                <input type="text" placeholder="Subject" className="input input-bordered" />
              </div>
              <div className="form-control mt-4">
                <label className="label"><span className="label-text">Message</span></label>
                <textarea placeholder="Write your message..." className="textarea textarea-bordered h-32" required />
              </div>
              <div className="mt-6">
                <button type="submit" className="btn btn-primary">
                  <Send className="w-4 h-4" />
                  <span className="ml-2">Send</span>
                </button>
              </div>
            </motion.form>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
